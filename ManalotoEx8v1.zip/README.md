# Perceptron Algorithm
An early model of the brain's neurons.

## How to run

```
python3 source_code/perceptron-algorithm.py
```